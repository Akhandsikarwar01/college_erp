"""
Production settings - extends base.py
All secrets must be provided via environment variables.
"""

import os
from .base import *  # noqa

DEBUG = False

SECRET_KEY = os.environ["DJANGO_SECRET_KEY"]  # Fail loudly if missing

ALLOWED_HOSTS = os.environ.get("ALLOWED_HOSTS", "").split(",")

# HTTPS enforcement
SECURE_SSL_REDIRECT = True
SESSION_COOKIE_SECURE = True
CSRF_COOKIE_SECURE = True
SECURE_HSTS_SECONDS = 31536000
SECURE_HSTS_INCLUDE_SUBDOMAINS = True
SECURE_HSTS_PRELOAD = True

# PostgreSQL in production
# import dj_database_url
# DATABASES = {"default": dj_database_url.config(conn_max_age=600, ssl_require=True)}
