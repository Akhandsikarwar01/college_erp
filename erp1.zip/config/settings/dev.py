"""
Development settings - extends base.py
"""

from .base import *  # noqa

DEBUG = True
SECRET_KEY = "dev-insecure-key-do-not-use-in-prod"
ALLOWED_HOSTS = ["*"]

# Use console email in dev
EMAIL_BACKEND = "django.core.mail.backends.console.EmailBackend"

# Disable whitenoise manifest in dev
STATICFILES_STORAGE = "django.contrib.staticfiles.storage.StaticFilesStorage"
