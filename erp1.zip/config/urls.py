from django.contrib import admin
from django.urls import path, include
from django.contrib.auth.views import LogoutView
from django.conf import settings
from django.conf.urls.static import static

from apps.core.views import home, dashboard
from apps.accounts.views import login_view, signup_view, verify_otp_view


urlpatterns = [
    # Admin
    path("admin/", admin.site.urls),

    # Public pages
    path("", home, name="home"),

    # Auth
    path("login/", login_view, name="login"),
    path("register/", signup_view, name="signup"),
    path("verify-otp/", verify_otp_view, name="verify_otp"),
    path("logout/", LogoutView.as_view(next_page="home"), name="logout"),

    # Dashboard (role-dispatched)
    path("dashboard/", dashboard, name="dashboard"),

    # App namespaced URLs
    path("accounts/", include("apps.accounts.urls")),
    path("academics/", include("apps.academics.urls")),
    path("attendance/", include("apps.attendance.urls")),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
