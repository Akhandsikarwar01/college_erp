"""
Core views: home page and role-dispatched dashboard.
"""

from django.contrib.auth.decorators import login_required
from django.db.models import Count, Q
from django.shortcuts import render

from apps.accounts.models import CustomUser, Role
from apps.attendance.models import AttendanceRecord, AttendanceSession


def home(request):
    return render(request, "core/home.html")


@login_required
def dashboard(request):
    user = request.user

    # ── STUDENT ──────────────────────────────────────────────────────────────
    if user.is_student:
        if not hasattr(user, "student_profile"):
            return render(request, "dashboard/default.html", {
                "message": "Your student profile is not configured yet."
            })

        records = AttendanceRecord.objects.filter(
            student=user.student_profile
        ).select_related(
            "session__teacher_assignment__subject"
        )

        total   = records.count()
        present = records.filter(is_present=True).count()
        overall = round((present / total) * 100, 1) if total else 0

        # Subject-wise stats — correct path: subject not course
        subject_rows = records.values(
            "session__teacher_assignment__subject__name"
        ).annotate(
            total=Count("id"),
            present=Count("id", filter=Q(is_present=True)),
        ).order_by("session__teacher_assignment__subject__name")

        subject_attendance = []
        for row in subject_rows:
            pct = round((row["present"] / row["total"]) * 100, 1) if row["total"] else 0
            subject_attendance.append({
                "subject":    row["session__teacher_assignment__subject__name"],
                "total":      row["total"],
                "present":    row["present"],
                "absent":     row["total"] - row["present"],
                "percentage": pct,
                "is_low":     pct < 75,
            })

        return render(request, "dashboard/student_dashboard.html", {
            "total_classes":      total,
            "present_classes":    present,
            "absent_classes":     total - present,
            "overall_percentage": overall,
            "low_attendance":     overall < 75,
            "subject_attendance": subject_attendance,
        })

    # ── TEACHER ──────────────────────────────────────────────────────────────
    elif user.is_teacher:
        if not hasattr(user, "teacher_profile"):
            return render(request, "dashboard/default.html", {
                "message": "Your teacher profile is not configured yet."
            })

        sessions = (
            AttendanceSession.objects
            .filter(teacher_assignment__teacher=user.teacher_profile)
            .select_related(
                "teacher_assignment__subject",
                "teacher_assignment__section__class_obj__course",
            )
            .prefetch_related("records")
            .order_by("-date")
        )

        session_data = []
        for session in sessions:
            all_records = session.records.all()
            total   = all_records.count()
            present = all_records.filter(is_present=True).count()
            pct     = round((present / total) * 100, 1) if total else 0

            session_data.append({
                "session":    session,
                "total":      total,
                "present":    present,
                "absent":     total - present,
                "percentage": pct,
            })

        total_students = (
            AttendanceRecord.objects
            .filter(session__teacher_assignment__teacher=user.teacher_profile)
            .values("student")
            .distinct()
            .count()
        )

        return render(request, "dashboard/teacher_dashboard.html", {
            "session_data":   session_data,
            "total_sessions": sessions.count(),
            "total_students": total_students,
        })

    # ── ERP MANAGER / SUPERUSER ───────────────────────────────────────────────
    elif user.is_erp_manager:
        stats = {
            "total_sessions": AttendanceSession.objects.count(),
            "total_students": CustomUser.objects.filter(
                role=Role.STUDENT, is_approved=True
            ).count(),
            "total_teachers": CustomUser.objects.filter(
                role=Role.TEACHER, is_approved=True
            ).count(),
            "pending_students": CustomUser.objects.filter(
                role=Role.STUDENT, is_approved=False, is_verified=True
            ).count(),
            "pending_teachers": CustomUser.objects.filter(
                role=Role.TEACHER, is_approved=False, is_verified=True
            ).count(),
        }

        pending_users = CustomUser.objects.filter(
            is_approved=False, is_verified=True
        ).order_by("role", "date_joined")

        return render(request, "dashboard/erp_dashboard.html", {
            **stats,
            "pending_users": pending_users,
        })

    # ── FALLBACK ──────────────────────────────────────────────────────────────
    return render(request, "dashboard/default.html")
