"""
Academics AJAX endpoints - used for cascading dropdowns in forms.
All endpoints require authentication to prevent data leakage.
"""

from django.http import JsonResponse
from django.contrib.auth.decorators import login_required

from .models import Program, Course, Class, Section


@login_required
def get_programs(request):
    department_id = request.GET.get("department_id")
    qs = Program.objects.filter(department_id=department_id).values("id", "name")
    return JsonResponse(list(qs), safe=False)


@login_required
def get_courses(request):
    program_id = request.GET.get("program_id")
    qs = Course.objects.filter(program_id=program_id).values("id", "name")
    return JsonResponse(list(qs), safe=False)


@login_required
def get_classes(request):
    course_id = request.GET.get("course_id")
    qs = Class.objects.filter(course_id=course_id).values("id", "name")
    return JsonResponse(list(qs), safe=False)


@login_required
def get_sections(request):
    class_id = request.GET.get("class_id")
    qs = Section.objects.filter(class_obj_id=class_id).values("id", "name")
    return JsonResponse(list(qs), safe=False)
