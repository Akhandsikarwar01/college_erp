"""
Attendance views: create sessions, mark/bulk-update, lock, CSV export.
All views are teacher-gated; session ownership is verified on each action.
"""

import csv

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db import IntegrityError
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render

from apps.accounts.models import Role
from apps.faculty.models import TeacherAssignment

from .models import AttendanceRecord, AttendanceSession


def _assert_teacher(request):
    """Return True if user is a Teacher with a profile, else redirect."""
    return request.user.role == Role.TEACHER and hasattr(request.user, "teacher_profile")


def _owns_session(request, session):
    """Confirm the requesting teacher owns this session."""
    return session.teacher_assignment.teacher == request.user.teacher_profile


# ──────────────────────────────────────────────────────────────────────────────
# CREATE SESSION
# ──────────────────────────────────────────────────────────────────────────────

@login_required
def create_session(request):
    if not _assert_teacher(request):
        messages.error(request, "Access denied.")
        return redirect("dashboard")

    assignments = TeacherAssignment.objects.filter(
        teacher=request.user.teacher_profile
    ).select_related("subject", "section__class_obj__course")

    if request.method == "POST":
        assignment_id = request.POST.get("assignment")
        date          = request.POST.get("date")

        if not assignment_id or not date:
            messages.error(request, "Please fill in all fields.")
            return render(request, "attendance/create_session.html", {"assignments": assignments})

        # Ensure the teacher owns this assignment
        if not assignments.filter(id=assignment_id).exists():
            messages.error(request, "Invalid assignment selected.")
            return render(request, "attendance/create_session.html", {"assignments": assignments})

        try:
            AttendanceSession.objects.create(
                teacher_assignment_id=assignment_id, date=date
            )
            messages.success(request, "Attendance session created successfully.")
        except IntegrityError:
            messages.error(request, "A session already exists for this subject on that date.")

        return redirect("dashboard")

    return render(request, "attendance/create_session.html", {"assignments": assignments})


# ──────────────────────────────────────────────────────────────────────────────
# MARK ATTENDANCE
# ──────────────────────────────────────────────────────────────────────────────

@login_required
def mark_attendance(request, session_id):
    if not _assert_teacher(request):
        messages.error(request, "Access denied.")
        return redirect("dashboard")

    session = get_object_or_404(
        AttendanceSession.objects.select_related("teacher_assignment__teacher"),
        id=session_id,
    )

    if not _owns_session(request, session):
        messages.error(request, "You do not own this session.")
        return redirect("dashboard")

    if session.is_locked:
        messages.warning(request, "This session is locked and cannot be edited.")
        return redirect("dashboard")

    records = session.records.select_related("student__user").order_by(
        "student__roll_number"
    )

    if request.method == "POST":
        present_ids = set(request.POST.getlist("present_students"))

        to_update = []
        for record in records:
            record.is_present = str(record.id) in present_ids
            to_update.append(record)

        AttendanceRecord.objects.bulk_update(to_update, ["is_present"])
        messages.success(request, "Attendance saved successfully.")
        return redirect("dashboard")

    return render(
        request,
        "attendance/mark_attendance.html",
        {"session": session, "records": records},
    )


# ──────────────────────────────────────────────────────────────────────────────
# LOCK SESSION
# ──────────────────────────────────────────────────────────────────────────────

@login_required
def lock_session(request, session_id):
    if not _assert_teacher(request):
        messages.error(request, "Access denied.")
        return redirect("dashboard")

    session = get_object_or_404(AttendanceSession, id=session_id)

    if not _owns_session(request, session):
        messages.error(request, "You do not own this session.")
        return redirect("dashboard")

    if session.is_locked:
        messages.info(request, "Session is already locked.")
    else:
        session.is_locked = True
        session.save(update_fields=["is_locked"])
        messages.success(request, "Session locked. No further edits allowed.")

    return redirect("dashboard")


# ──────────────────────────────────────────────────────────────────────────────
# EXPORT CSV
# ──────────────────────────────────────────────────────────────────────────────

@login_required
def export_attendance_csv(request, session_id):
    if not _assert_teacher(request):
        messages.error(request, "Access denied.")
        return redirect("dashboard")

    session = get_object_or_404(AttendanceSession, id=session_id)

    if not _owns_session(request, session):
        messages.error(request, "You do not own this session.")
        return redirect("dashboard")

    records = session.records.select_related("student__user").order_by(
        "student__roll_number"
    )

    response = HttpResponse(content_type="text/csv")
    response["Content-Disposition"] = (
        f'attachment; filename="attendance_{session.date}_{session.id}.csv"'
    )

    writer = csv.writer(response)
    writer.writerow(["Roll Number", "Name", "Status"])

    for rec in records:
        writer.writerow([
            rec.student.roll_number,
            rec.student.user.full_name,
            "Present" if rec.is_present else "Absent",
        ])

    return response
